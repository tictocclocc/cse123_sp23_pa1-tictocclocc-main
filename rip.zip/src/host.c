#include "host.h"
#include "sender.h"
#include "receiver.h"
#include <assert.h>

void init_host(Host* host, int id) {
    host->id = id;
    host->active = 0; 
    host->awaiting_ack = 0; 
    host->input_cmdlist_head = NULL;
    host->incoming_frames_head = NULL; 
    host->buffered_outframes_head = NULL; 
    host->buffered_inframes_head_1 = NULL; 
    host->outgoing_frames_head = NULL; 
    host->buffered_inacks_head = NULL;
    host->buffered_timeouts = NULL;
    host->send_window = calloc(glb_sysconfig.window_size, sizeof(struct send_window_slot)); 
    for (int i = 0; i < glb_sysconfig.window_size; i++) {
        host->send_window[i].frame = NULL;
        host->send_window[i].timeout = NULL;
    }
    host->rec_window_1 = calloc(glb_sysconfig.window_size, sizeof(Frame)); 
    host->rec_count_1 = calloc(glb_sysconfig.window_size, sizeof(int));
    host->ack_count = calloc(glb_sysconfig.window_size, sizeof(int));
    
    // TODO: You should fill in this function as necessary to initialize variables
    host->lfs = -1;
    host->lar = -1;
    host->lcfr = -1;
    

}

struct timeval* host_get_next_expiring_timeval(Host* host) {
    // TODO: You should fill in this function so that it returns the 
    // timeval when next timeout should occur
    // 
    // 1) Check your send_window for the timeouts of the frames. 
    // 2) Return the timeout of a single frame. 
    // HINT: It's not the frame with the furtherst/latest timeout.
    /*
    fprintf(stderr, "get next expire timeval\n");
    int mini = -1;
    int mintime = __INT_MAX__; 
    for(int i=0;i<glb_sysconfig.window_size;i++){
        if(&host->ac){
            return NULL;
        }
        fprintf(stderr, "calculate timeval\n");
        struct send_window_slot* s = &host->send_window[i];
        struct timeval* t = s->timeout;
        fprintf(stderr, "here\n");
        fprintf(stderr, "timeval sec: %ld\n",t->tv_sec);


        int currtimeout = t->tv_sec*1000000 + s->timeout->tv_usec;
        
        if(currtimeout < mintime){
            mintime = currtimeout;
            mini = i;
        }
    }
    
    return host->send_window[mini].timeout;*/
}

void run_hosts() {
    struct timeval curr_timeval;
    gettimeofday(&curr_timeval, NULL);

    int i; 
    for (i = 0; i < glb_num_hosts; i++) {
        Host* host = &glb_hosts_array[i]; 

        // Check whether anything has arrived
        int input_cmd_length = ll_get_length(host->input_cmdlist_head);
        int inframe_queue_length = ll_get_length(host->incoming_frames_head);
        struct timeval* next_timeout = host_get_next_expiring_timeval(host); 
        
        // Conditions to "wake up" the host:
        //    1) Acknowledgement or new command
        //    2) Timeout      
        int incoming_frames_cmds = (input_cmd_length != 0) | (inframe_queue_length != 0); 
        long reached_timeout = (next_timeout != NULL) && (timeval_usecdiff(&curr_timeval, next_timeout) <= 0);

        host->awaiting_ack = 0; 
        host->active = 0; 

        if (incoming_frames_cmds || reached_timeout) {
            fprintf(stderr, "handle input cmds\n");
            // Implement this
            handle_input_cmds(host);

            fprintf(stderr, "handle incomign frames\n");
            // Implement this
            handle_incoming_frames(host); 
            fprintf(stderr, "handle incomign acks\n");
            // Implement this
            handle_incoming_acks(host);
            fprintf(stderr, "handle timedout frames\n");
            // Implement this
            handle_timedout_frames(host);
            fprintf(stderr, "handle outgoing frames\n");
            // Implement this
            handle_outgoing_frames(host); 
        }
        
        //Condition to indicate that the host is still waiting for an ack
        for (int j = 0; j < glb_sysconfig.window_size; j++) {
            if (host->send_window[j].frame != NULL) {
                host->awaiting_ack = 1; 
                break; 
            }
        }
        fprintf(stderr, "1\n");
        //Condition to indicate that the host is active 
        if (host->awaiting_ack || ll_get_length(host->buffered_outframes_head) > 0) {
            host->active = 1; 
        }
        fprintf(stderr, "2\n");
    }
 
}