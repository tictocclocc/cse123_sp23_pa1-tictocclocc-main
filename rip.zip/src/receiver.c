#include "host.h"
#include <assert.h>
#include <stdbool.h>

void handle_incoming_frames(Host* host) {
    // TODO: Suggested steps for handling incoming frames
    //    1) Dequeue the Frame from the host->incoming_frames_head
    //    2) Compute CRC of incoming frame to know whether it is corrupted
    //    3) If frame is corrupted, drop it and move on.
    //    4) If frame is not corrupted, check if it is an ack frame
    //    5) If frame is an ack frame, save it to handle it in handle_incoming_acks
    //    6) Implement logic to check if the expected frame has come
    //    7) Implement logic to combine payload received from all frames belonging to a message
    //       and print the final message when all frames belonging to a message have been received.
    //    8) Implement the cumulative acknowledgement part of the sliding window protocol
    //    9) Append acknowledgement frames to the outgoing_frames_head queue
    int incoming_frames_length = ll_get_length(host->incoming_frames_head);
    
    while (incoming_frames_length > 0) {
        fprintf(stderr, "there are incoming frames\n");
        // Pop a node off the front of the link list and update the count
        LLnode* ll_inmsg_node = ll_pop_node(&host->incoming_frames_head);
        incoming_frames_length = ll_get_length(host->incoming_frames_head);

        
        Frame* inframe = ll_inmsg_node->value; 

        if(inframe->isAck==1){
            ll_append_node(&host->buffered_inacks_head,inframe);

        }else{



            //printf("<RECV_%d>:[%s]\n", host->id, inframe->data);
            if(inframe->seq_num <= host->lcfr + glb_sysconfig.window_size){
                fprintf(stderr, "frame seq num %d within window size of lcfr %d,\npopping off queue\n", inframe->seq_num, host->lcfr);
                //ll_append_node(&host->buffered_inframes_head_1,inframe);


                //sending ack
                Frame* outgoing_frame = malloc(sizeof(Frame));
                assert(outgoing_frame);
                outgoing_frame->isAck = 1; 
                outgoing_frame->src_id = inframe->dst_id;
                outgoing_frame->dst_id = inframe->src_id;
                outgoing_frame->seq_num = inframe->seq_num;
                outgoing_frame->total_frames = 1;
                ll_append_node(&host->outgoing_frames_head, outgoing_frame);

                
                int windownum = (inframe->seq_num)%glb_sysconfig.window_size;
                if(host->rec_window_1[windownum] == 0){
                    host->rec_window_1[windownum] = inframe;
                    host->rec_count_1[windownum] = 1;
                }

                bool allone = true;
                for(int k=0;k<glb_sysconfig.window_size;k++){
                    if(host->rec_count_1[k] != 1){
                        allone = false;
                    }
                }
                if(allone){
                    for(int m=0;m<glb_sysconfig.window_size;m++){
                        ll_append_node(&host->buffered_inframes_head_1,host->rec_window_1[m]);
                        host->rec_window_1[m] = 0;
                        host->rec_count_1[m] = 0;
                    }

                }
                    
                



                /*
                int newlcfr = host->lcfr; 
                int lastlcfr = newlcfr;
                fprintf(stderr, "curr lcfr = %d, finding new lcfr\n", host->lcfr);
                while(1){
                    //fprintf(stderr, "check for inf outer loop");
                    LLnode* cnode = host->buffered_inframes_head_1;
                    
                    for(int i=0;i<ll_get_length(host->buffered_inframes_head_1);i++){
                        Frame* f = cnode->value;
                        //fprintf(stderr, "check for inf inner loop");
                        if(f->seq_num == newlcfr + 1){

                            newlcfr++;
                            fprintf(stderr, "found higher lcfr %d\n", newlcfr);
                            break;
                        }
                        cnode = cnode->next;
                        
                    }
                    if(newlcfr == lastlcfr){
                        fprintf(stderr, "new lcfr is %d\n",newlcfr);
                        break;
                    }
                    lastlcfr = newlcfr;
                }
                host->lcfr = newlcfr;
            }
            */
            //free(inframe);
            //free(ll_inmsg_node);



            int buffered_inframes_head_1_length = ll_get_length(host->buffered_inframes_head_1);
            if(buffered_inframes_head_1_length > 0){
                fprintf(stderr, "there are frames\n");
                Frame* firstframe = host->buffered_inframes_head_1->value;
                int size = firstframe->total_frames;
                fprintf(stderr, "total frames: %d, current frames in buffer: %d\n",size,buffered_inframes_head_1_length);
                if(buffered_inframes_head_1_length == size){
                    fprintf(stderr, "all frames obtained\n");
                    char * arr[size];
                    
                    while(buffered_inframes_head_1_length > 0){
                        LLnode* innode = ll_pop_node(&host->buffered_inframes_head_1);
                        buffered_inframes_head_1_length = ll_get_length(host->buffered_inframes_head_1);
                        Frame* currframe = innode->value;
                        
                        arr[currframe->seq_num] = currframe->data;
                        fprintf(stderr, "added %s to array\n", currframe->data);
                    }
                        
                    fprintf(stderr, "combining all frames\n");
                    printf("combined: <RECV_%d>:[",host->id);
                    //char * str = "";
                    for(int i=0;i<size;i++){
                        printf("%s",arr[i]);
                        //fprintf(stderr, "str:%s, arr[i] = %s\n",str,arr[i]);
                        //str = strcat(str,arr[i]);
                        
                    }
                    printf("]\n");

                    //printf("combined: <RECV_%d>:[%s]\n", host->id, str);
                    
                    fprintf(stderr, "done\n");
                    }
                }
            }
        }

    }
    
    
}
